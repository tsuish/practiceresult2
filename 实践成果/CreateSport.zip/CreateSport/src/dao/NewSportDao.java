package dao;

public interface NewSportDao {

}
