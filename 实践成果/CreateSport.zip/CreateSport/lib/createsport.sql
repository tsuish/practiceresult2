/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50508
Source Host           : localhost:3306
Source Database       : createsport

Target Server Type    : MYSQL
Target Server Version : 50508
File Encoding         : 65001

Date: 2018-07-22 07:47:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `newitem`
-- ----------------------------
DROP TABLE IF EXISTS `newitem`;
CREATE TABLE `newitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsportid` int(11) DEFAULT NULL COMMENT '项目所属运动会的id',
  `name` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `peoplenum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of newitem
-- ----------------------------
INSERT INTO `newitem` VALUES ('1', '1', '跳绳', '2018-6-9到2018-9-8', '中原工学院南区', '100');
INSERT INTO `newitem` VALUES ('2', '1', '跳远', '2018-6-9到2018-9-8', '中原工学院南区', '99');
INSERT INTO `newitem` VALUES ('5', '1', 'tiaoa', '2018-6-9到2018-9-8', '中原工学院南区', '99');
INSERT INTO `newitem` VALUES ('6', '1', 'tiaoaa', '2018-6-9到2018-9-8', '中原工学院南区', '99');
INSERT INTO `newitem` VALUES ('7', '2', '跳远', '2018-6-9到2018-9-8', '中原工学院南区', '99');
INSERT INTO `newitem` VALUES ('9', '2', '跳绳', '2018-6-9到2018-9-8', '中原工学院南区', '99');
INSERT INTO `newitem` VALUES ('22', '8', '跳远', '2018年5月11日9:00到11:00', '中原工学院北区', '50');

-- ----------------------------
-- Table structure for `newsport`
-- ----------------------------
DROP TABLE IF EXISTS `newsport`;
CREATE TABLE `newsport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of newsport
-- ----------------------------
INSERT INTO `newsport` VALUES ('1', '第三次');
INSERT INTO `newsport` VALUES ('2', '第四次');
INSERT INTO `newsport` VALUES ('3', '第一次');
INSERT INTO `newsport` VALUES ('4', '第二次');
INSERT INTO `newsport` VALUES ('5', '第五次');
INSERT INTO `newsport` VALUES ('6', '第六次');
INSERT INTO `newsport` VALUES ('7', '第七次');
INSERT INTO `newsport` VALUES ('8', '2018年中原工学院运动会');
