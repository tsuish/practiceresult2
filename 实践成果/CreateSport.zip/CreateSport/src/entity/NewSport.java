package entity;

public class NewSport {
	private static int id;//运动会id
	private static String name;//运动会名称（年度、届次）
	private static String item;//项目id加一块。取时直接分开取
	public static int getId() {
		return id;
	}
	public static void setId(int id) {
		NewSport.id = id;
	}
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		NewSport.name = name;
	}
	public static String getItem() {
		return item;
	}
	public static void setItem(String item) {
		NewSport.item = item;
	}
}
