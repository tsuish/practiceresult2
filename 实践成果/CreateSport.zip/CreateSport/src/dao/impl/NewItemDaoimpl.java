package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.NewItemDao;

public class NewItemDaoimpl implements NewItemDao{
	public static void add(int sportid,String name,String time,String address,int peoplenum){//添加运动会项目
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		try {
			ps=conn.prepareStatement("insert into newitem(newsportid,name,time,address,peoplenum) values(?,?,?,?,?)");
			ps.setInt(1,sportid);
			ps.setString(2,name);
			ps.setString(3,time);
			ps.setString(4,address);
			ps.setInt(5,peoplenum);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(null, ps, conn);
		}
	}
	public static int queryonlyname(int sportid,String name){//检验运动会项目名字是否唯一
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		int flag=0;//唯一返回项目id,不唯一返回0
		try {
			ps=conn.prepareStatement("select id from newitem where newsportid=? and name=?");
			ps.setInt(1,sportid);
			ps.setString(2,name);
			rs=ps.executeQuery();
			if(rs.next()){
				flag=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return flag;
	}
	public static int queryid(int sportid,String name){//根据运动会项目名字和所属运动会id查项目id,返回id
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		int id=0;
		try {
			ps=conn.prepareStatement("select id from newitem where newsportid=? and name=?");
			ps.setInt(1,sportid);
			ps.setString(2,name);
			rs=ps.executeQuery();
			if(rs.next()){
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return id;
	}
	public static void update(int id,String name,String time,String address,int peoplenum){//根据id修改运动会项目
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		try {
			ps=conn.prepareStatement("update newitem set name=?,time=?,address=?,peoplenum=? where id=?");
			ps.setString(1,name);
			ps.setString(2,time);
			ps.setString(3,address);
			ps.setInt(4,peoplenum);
			ps.setInt(5,id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(null, ps, conn);
		}
	}
	public static String queryname(int id){//根据项目id查项目名称,返回名称
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String name="123";
		try {
			ps=conn.prepareStatement("select name from newitem where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			if(rs.next()){
				name=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return name;
	}
	public static String querytime(int id){//根据项目id查项目时间范围,返回时间范围
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String time="";
		try {
			ps=conn.prepareStatement("select time from newitem where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			if(rs.next()){
				time=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return time;
	}
	public static String queryaddress(int id){//根据项目id查项目举办地点,返回举办地点
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String address="";
		try {
			ps=conn.prepareStatement("select address from newitem where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			if(rs.next()){
				address=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return address;
	}
	public static int querypeoplenum(int id){//根据项目id查项目限定人数,返回限定人数
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		int peoplenum=0;
		try {
			ps=conn.prepareStatement("select peoplenum from newitem where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			if(rs.next()){
				peoplenum=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return peoplenum;
	}
	public static boolean delete(int id){//根据项目id删除项目,删除成功返回true,失败返回false
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		int rows=0;
		boolean flag=false;
		try {
			ps=conn.prepareStatement("delete from newitem where id=?");
			ps.setInt(1,id);
			rows=ps.executeUpdate();
			if(rows>0){
				flag=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(null, ps, conn);
		}
		return flag;
	}
	public static ResultSet querysportid(int sportid){//根据运动会id查项目详细信息,返回信息
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps=conn.prepareStatement("select name,time,address,peoplenum,id from newitem where newsportid=?");
			ps.setInt(1,sportid);
			rs=ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
