package entity;

public class NewItem {
	private static int id;
	private static String name;
	private static String time;//项目起始时间
	private static String address;
	private static int peoplenum;//项目人数
	public static int getId() {
		return id;
	}
	public static void setId(int id) {
		NewItem.id = id;
	}
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		NewItem.name = name;
	}
	public static String getTime() {
		return time;
	}
	public static void setTime(String time) {
		NewItem.time = time;
	}
	public static String getAddress() {
		return address;
	}
	public static void setAddress(String address) {
		NewItem.address = address;
	}
	public static int getPeoplenum() {
		return peoplenum;
	}
	public static void setPeoplenum(int peoplenum) {
		NewItem.peoplenum = peoplenum;
	}
}
