package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.NewItemDaoimpl;

public class HandleItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String choice=request.getParameter("choice");
		String exe=request.getParameter("exe");
		int sportid=Integer.parseInt(request.getParameter("sportid"));
		if(exe.equals("删除")){
			out.print("正在删除项目"+choice+"...<br>");
			if(NewItemDaoimpl.delete(Integer.parseInt(choice))){
				out.print("删除项目"+choice+"成功");
			}
		}else if(exe.equals("添加")){
			response.sendRedirect("http://localhost:8080/CreateSport/createitem?sportid="+sportid+"");
		}else if(exe.equals("修改")){
			response.sendRedirect("http://localhost:8080/CreateSport/updateitem?sportid="+sportid+"&id="+Integer.parseInt(choice));
		}
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}
