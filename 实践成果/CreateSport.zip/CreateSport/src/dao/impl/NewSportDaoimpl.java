package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.NewSportDao;

public class NewSportDaoimpl implements NewSportDao{
	public static void add(String name){//添加运动会
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		try {
			ps=conn.prepareStatement("insert into newsport(name) values(?)");
			ps.setString(1,name);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(null, ps, conn);
		}
	}
	public static boolean queryonlyname(String name){//检验运动会名字是否唯一
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		boolean flag=true;//唯一返回true,不唯一返回false
		try {
			ps=conn.prepareStatement("select id from newsport where name=?");
			ps.setString(1,name);
			rs=ps.executeQuery();
			if(rs.next()){
				flag=false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return flag;
	}
	public static int queryid(String name){//根据运动会名称查id,返回id
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		int id=0;
		try {
			ps=conn.prepareStatement("select id from newsport where name=?");
			ps.setString(1,name);
			rs=ps.executeQuery();
			if(rs.next()){
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return id;
	}
	public static String queryname(int id){//根据运动会id查名称,返回名称
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String name="";
		try {
			ps=conn.prepareStatement("select name from newsport where id=?");
			ps.setInt(1,id);
			rs=ps.executeQuery();
			if(rs.next()){
				name=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(rs, ps, conn);
		}
		return name;
	}
	public static void update(int id,String name,String item){//根据id修改运动会
		Connection conn=util.DBUtil.getConnection();
		PreparedStatement ps=null;
		try {
			ps=conn.prepareStatement("update newsport set name=?,item=? where id=?");
			ps.setString(1,name);
			ps.setString(2,item);
			ps.setInt(3,id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			util.DBUtil.closeConnection(null, ps, conn);
		}
	}
}
