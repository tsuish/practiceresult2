package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.NewSportDaoimpl;

public class NewSportServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String name=request.getParameter("sport_name");
		if(!NewSportDaoimpl.queryonlyname(name)){
			out.println("运动会名称已存在！！");
			out.println("<a href='http://localhost:8080/CreateSport/createsport'>重新创建运动会</a>");
		}else{
			NewSportDaoimpl.add(name);
			out.println("运动会"+name+"已添加成功");
			out.println("<a href='http://localhost:8080/CreateSport/createitem?sportid="+NewSportDaoimpl.queryid(name)+"'>继续添加运动会项目</a>");
		}
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>NewSportServlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}
