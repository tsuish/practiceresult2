package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.NewItemDaoimpl;

public class UpdateItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		int sportid=Integer.parseInt(request.getParameter("sportid"));
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("item_name");
		String time=request.getParameter("item_time");
		String address=request.getParameter("item_address");
		int peoplenum=Integer.parseInt(request.getParameter("item_peoplenum"));
			NewItemDaoimpl.update(id, name, time, address, peoplenum);
			out.println("运动会项目"+name+"已修改成功<br>");
			out.println("<a href='http://localhost:8080/CreateSport/IndexSport?sportid="+sportid+"'>查看运动会项目</a>");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>NewItemServlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}
