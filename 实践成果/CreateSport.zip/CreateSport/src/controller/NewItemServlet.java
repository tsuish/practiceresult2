package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.NewItemDaoimpl;
import dao.impl.NewSportDaoimpl;

public class NewItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		int sportid=Integer.parseInt(request.getParameter("sportid"));
		String name=request.getParameter("item_name");
		String time=request.getParameter("item_time");
		String address=request.getParameter("item_address");
		int peoplenum=Integer.parseInt(request.getParameter("item_peoplenum"));
		if(NewItemDaoimpl.queryonlyname(sportid, name)!=0){
			out.println("运动会项目名称已存在！！");
			out.println("<a href='http://localhost:8080/CreateSport/createitem?sportid="+sportid+"'>重新创建运动会项目</a>");
		}else{
			NewItemDaoimpl.add(sportid,name,time, address, peoplenum);
			out.println("运动会项目"+name+"已添加成功<br>");
			out.println("<a href='http://localhost:8080/CreateSport/createitem?sportid="+sportid+"'>继续添加运动会项目</a><br>");
			out.println("<a href='http://localhost:8080/CreateSport/IndexSport?sportid="+sportid+"'>查看已添加运动会项目</a>");
		}
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>NewItemServlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}
