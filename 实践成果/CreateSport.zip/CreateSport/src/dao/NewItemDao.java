package dao;

public interface NewItemDao {

}
